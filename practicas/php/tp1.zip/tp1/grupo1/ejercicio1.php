<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ejercicio 1</title>
  </head>
  <body>
    <?php
      $var = 10;
    ?>
    <h2><?php  echo var_dump($var);?></h2>
  </body>
</html>
