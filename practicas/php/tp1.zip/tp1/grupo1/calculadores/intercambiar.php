<?php
$var1 = $_POST["var1"];
$var2 = $_POST["var2"];

echo "Variable 1: ".$var2."<br><br>";
echo "Variable 2: ".$var1."<br><br>";

 ?>
