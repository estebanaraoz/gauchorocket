<?php
$base = $_POST["base"];
$altura = $_POST["altura"];

$area = ($base*$altura) / 2;

echo "El área del triángulo es: ".$area;


 ?>
