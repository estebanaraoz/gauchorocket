<?php
$base = $_POST["base"];
$altura = $_POST["altura"];

$area = ($base*$altura);

echo "El área del rectángulo es: ".$area;


 ?>
