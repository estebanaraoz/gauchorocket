<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ejercicio 5</title>
  </head>
  <body>
    <form class="" action="calculadores/intercambiar.php" method="post">
      Variable 1: <input type="text" name="var1" value=""> <br><br>
      Variable 2: <input type="text" name="var2" value=""> <br><br>

      <button type="submit" name="button">Intercambiar</button>
  </body>
</html>
