<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ejercicio 3</title>
  </head>
  <body>
    <form class="" action="calculadores/areaRectangulo.php" method="post">
      Base: <input type="text" name="base" value=""> <br><br>
      Altura: <input type="text" name="altura" value=""> <br><br>

      <button type="submit" name="button">Calcular</button>

    </form>

  </body>
</html>
