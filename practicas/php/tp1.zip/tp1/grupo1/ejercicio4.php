<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ejercicio 4</title>
  </head>
  <body>
    <form class="" action="calculadores/areaTrapecio.php" method="post">
      Base Mayor: <input type="text" name="baseMayor" value=""> <br><br>
      Base Menor: <input type="text" name="baseMenor" value=""> <br><br>
      Altura: <input type="text" name="altura" value=""> <br><br>

      <button type="submit" name="button">Calcular</button>

    </form>
  </body>
</html>
