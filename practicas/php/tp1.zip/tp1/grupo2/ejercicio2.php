<?php


for ($i=100; $i>=0 ; $i-=2) {
  echo ($i)."<br>";
}

 ?>
