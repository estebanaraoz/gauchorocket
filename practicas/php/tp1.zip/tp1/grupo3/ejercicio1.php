<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ejercicio 1</title>
  </head>
  <body>
    <p>x2+2*x+b</p>
    <form class="" action="calculadores/ecuacion.php" method="post">
      x = <input type="text" name="x" value=""> <br><br>
      b = <input type="text" name="b" value=""> <br><br>

      <button type="submit" name="button">Calcular</button>

    </form>
  </body>
</html>
