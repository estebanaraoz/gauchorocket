<?php

$valor1 = $_POST["val1"];
$valor2 = $_POST["val2"];
$valor3 = $_POST["val3"];

echo "El mayor es: ".max($valor1, $valor2, $valor3);

 ?>
