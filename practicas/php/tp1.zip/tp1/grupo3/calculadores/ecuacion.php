<?php

$x = $_POST["x"];
$b = $_POST["b"];

$resultado = $x*2+2*$x+$b;

echo $resultado;



 ?>
