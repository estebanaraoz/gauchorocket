<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ejercicio 5</title>
  </head>
  <body>
    <p>x2+2*x+b</p>
    <form class="" action="calculadores/calcularIntermedio.php" method="post">
      Valor 1 = <input type="text" name="val1" value=""> <br><br>
      Valor 2 = <input type="text" name="val2" value=""> <br><br>
      Valor 3 = <input type="text" name="val3" value=""> <br><br>

      <button type="submit" name="button">Calcular mayor</button>

    </form>
  </body>
</html>
